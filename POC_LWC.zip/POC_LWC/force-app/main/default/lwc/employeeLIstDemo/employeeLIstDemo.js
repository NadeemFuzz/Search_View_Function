import { LightningElement, wire, track } from 'lwc';
import getEmployeeList from '@salesforce/apex/EmployeeAuraService.getEmployeeList';

export default class EmployeeLIstDemo extends LightningElement {

@track searchKey;    
@track employees;
@track error;
@wire(getEmployeeList , {
    name : '$searchKey'
})
wiredEmployee({error, data}){
    if(data){
        this.employees = data;
    }
    if(error){
        this.error = error;
        /* eslint-disable no-console */
        console.log('Error', error);
    }
}


handleChange(event){
    event.preventDefault();

    /* eslint-disable no-console */
    console.log('Valuue '+ event.target.value)
    this.searchKey = event.target.value;
}


}