declare module "@salesforce/apex/EmployeeAuraService.getEmployeeList" {
  export default function getEmployeeList(param: {name: any}): Promise<any>;
}
declare module "@salesforce/apex/EmployeeAuraService.getAccountList" {
  export default function getAccountList(param: {name: any}): Promise<any>;
}
